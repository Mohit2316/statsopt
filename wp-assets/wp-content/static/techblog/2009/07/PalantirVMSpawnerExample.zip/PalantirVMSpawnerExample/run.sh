#!/bin/sh

ROOT_DIR=`dirname $0`

if [ ! -x `which java` ]; then
	echo no java executable could be found && exit 1
fi

java -jar ${ROOT_DIR}/lib/devblog-vmspawner.jar
