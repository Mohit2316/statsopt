package com.palantir.blog.processspawner;
/*
 * All source code and information in this file is made
 * available under the following licensing terms:
 *
 * Copyright (c) 2009, Palantir Technologies, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *
 *     * Redistributions in binary form must reproduce the above
 *       copyright notice, this list of conditions and the following
 *       disclaimer in the documentation and/or other materials provided
 *       with the distribution.
 *
 *     * Neither the name of Palantir Technologies, Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 */ 
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.UnknownHostException;

import junit.framework.TestCase;

/**
 * A simple ACK server functional test that will showcase a simple example of 
 * spawning external VMs during a JUnit {@link TestCase}.
 * 
 * @author regs
 *
 */
public class ServerSpawningTest extends TestCase {

	/**
	 * Our vmspawner that knows how to spin off
	 * new server VMs for every test.
	 */
	JavaInvoke vmspawner;
	/**
	 * The server process.
	 * 
	 * This field is managed by setup/teardown for each test case.
	 */
	Process p = null;
	
	/**
	 * The ACK {@link Client} object.
	 * 
	 * This field is managed by setup/teardown for each test case.
	 */	
	Client c = null;
	
	/**
	 * Starts our server VM and waits to make sure that it's accepting connections.
	 * 
	 */
	@Override
	protected void setUp() throws Exception {
		System.out.println("-----------------------------------------------------");
		System.out.println("Starting test " + getName());
		System.out.flush();
		super.setUp();
		vmspawner = new JavaInvoke(Server.class.getCanonicalName(),null,null,null,null,null);
		p = vmspawner.startStdinStderrInstance("server");
		boolean serverIsUp = Server.checkServerIsUp(10000, 100, getServerAddress(), getServerPort());
		assertTrue("Server did not become available",serverIsUp);
		c = new Client(getServerAddress(),getServerPort());
	}
	
	/**
	 * Makes sure to shutdown external VM. Careful error handling is needed to make
	 * sure that an exception doesn't stop the VM from being destroyed.
	 */
	@Override
	protected void tearDown() throws Exception {
		try {
			super.tearDown();
		} finally {
			try {
				try {
					Client.sendShutdown(getServerAddress(), getServerPort());
				} catch(ConnectException e) {
					// this is expected
				}
				catch(Exception e) {
					e.printStackTrace();
				}
				p.destroy();
				p.waitFor();
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			p = null;
		}
		System.out.println("Finished test " + getName());
		System.out.println("-----------------------------------------------------");
		System.out.flush();
	}
	
	/**
	 * Test the ACK function of the protocol
	 * @throws Exception
	 */
	public void testAck() throws Exception {
		String response = c.sendMessage("some message");
		assertEquals("Server sent us an unexpected response!",Server.ACK,response);
	}
	
	/**
	 * Test that the SHUTDOWN primitive is implemented correctly.
	 * 
	 * @throws Exception
	 */
	public void testShutdown() throws Exception {
		final long preShutdown = System.currentTimeMillis();
		Client.sendShutdown(getServerAddress(), getServerPort());
		final long shutdownSent = System.currentTimeMillis();
		p.waitFor();
		final long processDead = System.currentTimeMillis();
		System.out.println("Took " + (shutdownSent - preShutdown) + " ms to send shutdown.");
		System.out.println("Took " + (processDead - preShutdown) + " ms for process to die.");
		assertEquals("Expected process to exit with 0 exit code",0,p.exitValue());
	}
	
	InetAddress getServerAddress() throws UnknownHostException {
		return InetAddress.getLocalHost();
	}
	
	int getServerPort() {
		return Server.SERVERPORT;
	}
}
