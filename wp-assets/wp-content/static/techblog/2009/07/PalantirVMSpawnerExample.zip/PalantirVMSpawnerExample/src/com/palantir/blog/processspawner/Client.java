package com.palantir.blog.processspawner;

/*
 * All source code and information in this file is made
 * available under the following licensing terms:
 *
 * Copyright (c) 2009, Palantir Technologies, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *
 *     * Redistributions in binary form must reproduce the above
 *       copyright notice, this list of conditions and the following
 *       disclaimer in the documentation and/or other materials provided
 *       with the distribution.
 *
 *     * Neither the name of Palantir Technologies, Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 */ 

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.InetAddress;
import java.net.Socket;

import javax.net.SocketFactory;

/**
 * A simple network client.
 * 
 * @author regs
 *
 */
public class Client {
	
	final Socket connection;
	final BufferedReader r;
	final Writer w;
	
	public Client(InetAddress connectTo, int port) throws IOException {
		this.connection = SocketFactory.getDefault().createSocket(connectTo,port);
		this.connection.setTcpNoDelay(true);
		
		r = new BufferedReader(new InputStreamReader(this.connection.getInputStream()));
		w = new OutputStreamWriter(this.connection.getOutputStream());

	}

	public String sendMessage(String msg) throws IOException {
		if(!this.connection.isConnected()) {
			throw new IllegalStateException("Socket is not connected!");
		}
		try {
			w.write(msg + "\n");
			w.flush();
			String rc = r.readLine();
			return rc;
		} finally {
			
		}
	}

	public void close() {
		try {
			r.close();
		} catch(Exception e) {
			// close quietly
		}
		try {
			w.close();
		} catch(Exception e) {
			// close quietly
		}
		try {
			connection.close();
		}
		catch(Exception e) {
			// close quietly
		}
	}

	@Override
	protected void finalize() throws Throwable {
		super.finalize();
		close();
	}
	
	public static final void sendShutdown(InetAddress connectTo, int port) throws IOException {
		Client c = new Client(connectTo,port);
		c.sendMessage(Server.SHUTDOWN);
	}
}
