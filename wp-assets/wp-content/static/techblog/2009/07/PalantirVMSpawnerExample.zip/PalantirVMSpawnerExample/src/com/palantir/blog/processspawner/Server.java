package com.palantir.blog.processspawner;
/*
 * All source code and information in this file is made
 * available under the following licensing terms:
 *
 * Copyright (c) 2009, Palantir Technologies, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *
 *     * Redistributions in binary form must reproduce the above
 *       copyright notice, this list of conditions and the following
 *       disclaimer in the documentation and/or other materials provided
 *       with the distribution.
 *
 *     * Neither the name of Palantir Technologies, Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 */ 
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.concurrent.Executors;

import javax.net.ServerSocketFactory;
import javax.net.SocketFactory;

/**
 * A server that implements a simple <a href='http://en.wikipedia.org/wiki/ACK_(computing)'>ACK</a>
 * protocol: every message (a string matching the regex: /^.*$/) is answered with the string "ACK\n".
 * If the message "SHUTDOWN" is encountered, the process will exit.
 * 
 * This server spawns a handler thread for every incoming connection.  A more robust implementation
 * would use {@link Executors} to control the number of concurrent threads.
 * @author regs
 *
 */
public class Server extends Thread {

	public static final String	ACK	= "ACK";
	public static final int SERVERPORT = 10001;
	/**
	 * The only special command in this protocol.  If this message is received, the process will
	 * immediately exit, after ACKing, of course.
	 */
	public static final String SHUTDOWN = "SHUTDOWN"; 

	public static void main(String[] args)  throws Exception {
		
		ServerSocketFactory socketFactory = ServerSocketFactory.getDefault();
		ServerSocket serverSocket = socketFactory.createServerSocket(SERVERPORT);

		// infinite is exited by handler thread calling System.exit()
		while(true) {
			try {
				System.out.println("Waiting for connection");
				Socket connection = serverSocket.accept();
				System.out.println("Spawning socket handler");
				new Server(connection);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Thread-naming counter.
	 */
	static int count = 0;
	Socket connection;
	int id = 0;

	/**
	 * Starts a handler thread to handle the passed connection.
	 * 
	 * @param connection
	 * @throws IOException
	 */
	public Server(Socket connection) throws IOException {
		synchronized (getClass()) {
			id = ++count;
		}
		setName("Socket Handler" + id);
		this.connection = connection;
		this.start();
	}

	private void out(String message) {
		System.out.println("[" + getName() + "]: " + message);
	}

	/**
	 * The handler routine that actually implements the protocol.
	 */
	@Override
	public void run() {
		try {
			BufferedReader r = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			Writer w = new OutputStreamWriter(connection.getOutputStream());

			String line = null;
			do {
				line = r.readLine();

				if(line != null) {
					out("Got message: " + line);
					w.write(ACK + "\n");
					w.flush();
					
					// check for shutdown
					if(SHUTDOWN.equals(line)) {
						// kill it
						System.exit(0);
					}
				}
			} while ( line != null );
		} catch(SocketException e) {
			if("Connection Reset".equals(e.getMessage())) {
				// ignore - this is produced by the 
				// probing code to see if the server is up.
			}
		} catch (Exception e) {
			System.out.println("Error while handling socket");
			e.printStackTrace();
		}			
	}

	/**
	 * Repeats a TCP connection check every <em>sleepTime</em> milliseconds until it either succeeds
	 * or times out after <em>timeout</em> milliseconds.
	 * 
	 * @see Server#checkServerIsUp(InetAddress, int) An explanation of the TCP checking mechanism.
	 * 
	 * @param timeout If no check is successful after this many milliseconds has passed, fail the 
	 * overall checking process.
	 * @param sleepTime How long to wait (in milliseconds) between checks of the service.
	 * @param server address of server to check.
	 * @param port port to check.
	 * @return true if a connection attempt succeeds, false in the case of error or 
	 * no connection attempt successful.
	 */
	public static boolean checkServerIsUp(long timeout, long sleepTime,InetAddress server, int port ) {
		long start = System.currentTimeMillis();
		while((System.currentTimeMillis() - start) < timeout){
			if(!checkServerIsUp(server, port)){
				try {
					Thread.sleep(sleepTime);
				} catch (InterruptedException e) {
					return false;
				}
			}
			else{
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Performs a simple TCP connection check to the specified address and port.
	 * 
	 * @param server address of the server to contact.
	 * @param port TCP port to connect to on the specified server.
	 * @return true if that port is accepting connections, 
	 * false in all other cases: not listening and/or connection error.
	 */
	public static boolean checkServerIsUp(InetAddress server, int port) {
		Socket sock = null;
		try {
			sock = SocketFactory.getDefault().createSocket(server, port);
			sock.setSoLinger(true, 0);
			return true;
		} catch (IOException e) { 
			return false;
		}
		finally{
			if(sock != null){
				try {
					sock.close();
				} catch (IOException e) {
					// don't care
				}
			}
		}
	}
}
